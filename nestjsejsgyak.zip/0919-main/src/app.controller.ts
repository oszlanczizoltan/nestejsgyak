import { Controller, Get, Param, Query, Render } from '@nestjs/common';
import { AppService } from './app.service';
import { quotes } from './quotes';
import { query } from 'express';

 
 
 
@Controller()
export class AppController {
  quotes: any;
  constructor(private readonly appService: AppService) {}
 
  @Get('quotes')
  @Render('quotes')
  getQuotes() {
    return {quotes: quotes};
    }

  @Get('randomQuotes')
  @Render('randomQuotes')
  getRandomQuote(){
    const min = 1;
    const max = quotes.quotes.length;
    const num = Math.floor(Math.random()* max)

    const randomQuote = quotes.quotes[num]

    return {
      quote: randomQuote.quote,
      author: randomQuote.author
    };
  }

  @Get('topAuthors')
  @Render('topAuthors')
  getTopAuthors() {
    const authorCount = quotes.quotes.reduce((acc, quote) => {
      acc[quote.author] = (acc[quote.author] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const authors = Object.entries(authorCount).map(([author, count]) => ({ author, count }));
    return { authors };
  }


  @Get('quotes/:id')
  oneQuote(@Param('id') id: string) {
    const quote = this.quotes.find(q => q.id === +id);
    return quote || { message: 'Ismeretlen idézet' };
  }

  @Get('deleteQuotes')
  @Render('quotes')
  deleteQuote(@Param('id') id: string): { message: string; }{
    const index = this.quotes.findIndex(q => q.id === +id);
    if (index !== -1) {
      this.quotes.splice(index, 1);
      return {message: 'sikeres torles'};
    }
    return {message: 'ismeretlen idezet'};
  }

  @Get('search')
  @Render('search')
  search(@Query('quote') quote: string) {
    const results = this.quotes.filter(q => q.quote.includes(quote));
    return results;
  }

  @Get('authorRandom')
  @Render('authorRandomForm')
  authorRandom(@Query('author') author: string) {
    const filteredQuotes = quotes.quotes.filter(q => q.author === author);
    if (filteredQuotes.length > 0) {
      const randomQuote = filteredQuotes[Math.floor(Math.random() * filteredQuotes.length)];
      return { quote: randomQuote };
    }
    return { message: 'Nincs ilyen szerzőtől idézet' };
  }

  @Get('highlight/:id')
  @Render('quotes')
  highlight(@Param('id') id: string,@Query('text') text: string) {
    const quote=quotes.quotes.find(q => q.id === +id);
    if (quote) {
      const highlightedtext = quote.quote.replace(new RegExp(text, 'gi'), (match) => `<strong>${match}</strong>`);
      return {text: highlightedtext};
    }
  }

}



